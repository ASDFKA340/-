<?php
session_start();
require_once 'config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = trim($_POST['password'] ?? '');

    // --- Вход администратора ---
    if ($login === 'Admin26' && $password === 'Demo20') {
        $_SESSION['admin_logged'] = true;
        // Очищаем возможные остатки пользовательской сессии
        unset($_SESSION['user_id']);
        unset($_SESSION['user_name']);
        header('Location: admin.php');
        exit;
    }

    // --- Вход обычного пользователя ---
    $query = "SELECT * FROM users WHERE login = '$login' AND password = '$password'";
    $result = mysqli_query($conn, $query);
    if ($result && mysqli_num_rows($result) === 1) {
        $user = mysqli_fetch_assoc($result);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['fullname'];
        header('Location: profile.php');
        exit;
    } else {
        $error = 'Неверный логин или пароль.';
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Вход - Учусь.РФ</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<div class="form-card">
    <h2><i class="fas fa-sign-in-alt"></i> Авторизация</h2>
    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST">
        <div class="form-group">
            <label>Логин</label>
            <input type="text" name="login" required>
        </div>
        <div class="form-group">
            <label>Пароль</label>
            <input type="password" name="password" required>
        </div>
        <button type="submit">Войти</button>
        <div class="links">
            <a href="register.php">Нет аккаунта? Регистрация</a>
        </div>
    </form>
</div>
</body>
</html>