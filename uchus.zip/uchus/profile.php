<?php
session_start();
require_once 'config.php';
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];
$apps_query = "SELECT * FROM applications WHERE user_id = $user_id ORDER BY id DESC";
$apps_result = mysqli_query($conn, $apps_query);
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review'])) {
    $app_id = intval($_POST['app_id']);
    $review = trim($_POST['review']);
    $check = mysqli_query($conn, "SELECT status FROM applications WHERE id = $app_id AND user_id = $user_id");
    $row = mysqli_fetch_assoc($check);
    if ($row && $row['status'] === 'Обучение завершено') {
        $review_esc = mysqli_real_escape_string($conn, $review);
        mysqli_query($conn, "UPDATE applications SET review = '$review_esc' WHERE id = $app_id");
    }
    header('Location: profile.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Личный кабинет - Учусь.РФ</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<div class="container" style="padding:24px;">
    <div class="admin-header" style="background:#2b6cb0; margin-bottom:20px; border-radius:28px;">
        <h2><i class="fas fa-user-circle"></i> <?= htmlspecialchars($user_name) ?></h2>
        <div style="display:flex; gap:12px;">
            <a href="application.php" style="background:#48bb78;"><i class="fas fa-file-signature"></i> Новая заявка</a>
            <a href="logout.php" style="background:#e53e3e;"><i class="fas fa-sign-out-alt"></i> Выйти</a>
        </div>
    </div>

    <!-- Слайдер -->
    <div class="slider-container">
        <div class="slider" id="slider">
            <img src="https://picsum.photos/id/20/800/450" alt="Курсы">
            <img src="https://picsum.photos/id/26/800/450" alt="Обучение">
            <img src="https://picsum.photos/id/42/800/450" alt="Диплом">
            <img src="https://picsum.photos/id/29/800/450" alt="Студенты">
        </div>
        <button class="slider-btn prev" id="prevSlide"><i class="fas fa-chevron-left"></i></button>
        <button class="slider-btn next" id="nextSlide"><i class="fas fa-chevron-right"></i></button>
    </div>

    <h3>Мои заявки</h3>
    <div class="table-wrapper">
        <table>
            <thead><tr><th>Курс</th><th>Дата старта</th><th>Оплата</th><th>Статус</th><th>Отзыв</th></tr></thead>
            <tbody>
            <?php while($app = mysqli_fetch_assoc($apps_result)): 
                $status_class = '';
                if($app['status'] == 'Новая') $status_class = 'status-new';
                elseif($app['status'] == 'Идет обучение') $status_class = 'status-progress';
                else $status_class = 'status-done';
            ?>
            <tr>
                <td><?= htmlspecialchars($app['course_name']) ?></td>
                <td><?= htmlspecialchars($app['start_date']) ?></td>
                <td><?= htmlspecialchars($app['payment_method']) ?></td>
                <td><span class="status-badge <?= $status_class ?>"><?= $app['status'] ?></span></td>
                <td>
                    <?php if($app['status'] == 'Обучение завершено'): ?>
                        <?php if(!empty($app['review'])): ?>
                            <em><?= nl2br(htmlspecialchars($app['review'])) ?></em>
                        <?php else: ?>
                            <form method="POST">
                                <textarea name="review" rows="2" placeholder="Ваш отзыв..."></textarea>
                                <input type="hidden" name="app_id" value="<?= $app['id'] ?>">
                                <button type="submit" name="submit_review" class="btn-small">Оставить отзыв</button>
                            </form>
                        <?php endif; ?>
                    <?php else: ?>
                        <span class="status-badge status-new">Отзыв после завершения</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
<script>
    let slideIndex = 0;
    const slides = document.querySelectorAll('#slider img');
    const sliderDiv = document.getElementById('slider');
    function updateSlider() { sliderDiv.style.transform = `translateX(-${slideIndex * 100}%)`; }
    document.getElementById('nextSlide')?.addEventListener('click', () => { slideIndex = (slideIndex+1) % slides.length; updateSlider(); });
    document.getElementById('prevSlide')?.addEventListener('click', () => { slideIndex = (slideIndex-1+slides.length) % slides.length; updateSlider(); });
    setInterval(() => { if(document.getElementById('slider')) { slideIndex = (slideIndex+1) % slides.length; updateSlider(); } }, 3000);
</script>
</body>
</html>