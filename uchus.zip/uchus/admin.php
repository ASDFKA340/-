<?php
session_start();
require_once 'config.php';

// Если администратор не залогинен — отправляем на страницу входа
if (!isset($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
    header('Location: login.php');
    exit;
}

// Выход из админки
if (isset($_GET['logout'])) {
    unset($_SESSION['admin_logged']);
    session_destroy();
    header('Location: login.php');
    exit;
}

// Обновление статуса заявки
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $app_id = intval($_POST['app_id']);
    $new_status = mysqli_real_escape_string($conn, $_POST['new_status']);
    mysqli_query($conn, "UPDATE applications SET status = '$new_status' WHERE id = $app_id");
    header('Location: admin.php');
    exit;
}

// Фильтрация и сортировка
$filter = $_GET['status'] ?? 'all';
$sort = $_GET['sort'] ?? 'id';
$where = ($filter !== 'all') ? "WHERE a.status = '$filter'" : "";
$order = ($sort === 'date') ? "a.start_date" : "a.id";
$result = mysqli_query($conn, "SELECT a.*, u.fullname as user_name FROM applications a JOIN users u ON a.user_id = u.id $where ORDER BY $order DESC");
$applications = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Админ панель - Учусь.РФ</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<div class="admin-container">
    <div class="admin-header">
        <h2><i class="fas fa-tachometer-alt"></i> Панель администратора</h2>
        <a href="?logout=1"><i class="fas fa-sign-out-alt"></i> Выйти</a>
    </div>

    <div class="filter-card">
        <form method="GET" style="display:flex; gap:15px; flex-wrap:wrap;">
            <div class="filter-group">
                <label>Статус</label>
                <select name="status">
                    <option value="all" <?= $filter=='all' ? 'selected' : '' ?>>Все статусы</option>
                    <option value="Новая" <?= $filter=='Новая' ? 'selected' : '' ?>>Новая</option>
                    <option value="Идет обучение" <?= $filter=='Идет обучение' ? 'selected' : '' ?>>Идет обучение</option>
                    <option value="Обучение завершено" <?= $filter=='Обучение завершено' ? 'selected' : '' ?>>Обучение завершено</option>
                </select>
            </div>
            <div class="filter-group">
                <label>Сортировка</label>
                <select name="sort">
                    <option value="id" <?= $sort=='id' ? 'selected' : '' ?>>По ID</option>
                    <option value="date" <?= $sort=='date' ? 'selected' : '' ?>>По дате старта</option>
                </select>
            </div>
            <button type="submit"><i class="fas fa-search"></i> Применить</button>
        </form>
    </div>

    <div class="table-wrapper">
        <table>
            <thead>
                <tr><th>ID</th><th>Пользователь</th><th>Курс</th><th>Дата старта</th><th>Оплата</th><th>Статус</th><th>Действие</th></tr>
            </thead>
            <tbody>
            <?php foreach ($applications as $app):
                $status_class = '';
                if ($app['status'] == 'Новая') $status_class = 'status-new';
                elseif ($app['status'] == 'Идет обучение') $status_class = 'status-progress';
                else $status_class = 'status-done';
            ?>
                <tr>
                    <td><?= $app['id'] ?></td>
                    <td><?= htmlspecialchars($app['user_name']) ?></td>
                    <td><?= htmlspecialchars($app['course_name']) ?></td>
                    <td><?= htmlspecialchars($app['start_date']) ?></td>
                    <td><?= htmlspecialchars($app['payment_method']) ?></td>
                    <td><span class="status-badge <?= $status_class ?>"><?= $app['status'] ?></span></td>
                    <td>
                        <form method="POST" style="display:flex; gap:8px;">
                            <select name="new_status" class="status-select">
                                <option value="Новая" <?= $app['status']=='Новая' ? 'selected' : '' ?>>Новая</option>
                                <option value="Идет обучение" <?= $app['status']=='Идет обучение' ? 'selected' : '' ?>>Идет обучение</option>
                                <option value="Обучение завершено" <?= $app['status']=='Обучение завершено' ? 'selected' : '' ?>>Обучение завершено</option>
                            </select>
                            <input type="hidden" name="app_id" value="<?= $app['id'] ?>">
                            <button type="submit" name="update_status" class="btn-small">Изменить</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>