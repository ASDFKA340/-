<?php
session_start();
require_once 'config.php';
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
$error = $success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course = $_POST['course'];
    $date = $_POST['start_date'];
    $payment = $_POST['payment'];
    if (!preg_match('/^\d{2}\.\d{2}\.\d{4}$/', $date)) $error = 'Формат даты ДД.ММ.ГГГГ';
    else {
        $uid = $_SESSION['user_id'];
        mysqli_query($conn, "INSERT INTO applications (user_id, course_name, start_date, payment_method, status) VALUES ('$uid', '$course', '$date', '$payment', 'Новая')");
        $success = 'Заявка успешно отправлена!';
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Новая заявка - Учусь.РФ</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="form-card">
    <h2><i class="fas fa-calendar-plus"></i> Оформление заявки</h2>
    <?php if($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if($success): ?><div class="success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
    <form method="POST">
        <div class="form-group"><label>Курс</label><select name="course"><option>Курс повышения квалификации</option><option>Курс переподготовки</option><option>Курс по охране труда</option></select></div>
        <div class="form-group"><label>Дата старта (ДД.ММ.ГГГГ)</label><input name="start_date" placeholder="01.09.2026"></div>
        <div class="form-group"><label>Способ оплаты</label><select name="payment"><option>Банковская карта</option><option>Электронный кошелек</option><option>Безналичный расчет</option></select></div>
        <button type="submit">Отправить заявку</button>
        <div class="links"><a href="profile.php">← Вернуться в личный кабинет</a></div>
    </form>
</div>
</body>
</html>