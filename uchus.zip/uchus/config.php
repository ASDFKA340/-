<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'uchus_db';
$conn = mysqli_connect($host, $user, $pass, $dbname);
if (!$conn) die("Ошибка подключения: " . mysqli_connect_error());
mysqli_set_charset($conn, "utf8");
?>