<?php
session_start();
$error = '';

// Выход
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: minimal_admin.php');
    exit;
}

// Обработка входа
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_POST['login'] === 'Admin26' && $_POST['pass'] === 'Demo20') {
        $_SESSION['admin_ok'] = true;
        header('Location: minimal_admin.php');
        exit;
    } else {
        $error = 'Неверный логин или пароль';
    }
}

// Если уже залогинен
if (isset($_SESSION['admin_ok']) && $_SESSION['admin_ok'] === true) {
    echo "<h1>Вы вошли как администратор!</h1>";
    echo '<a href="?logout=1">Выйти</a>';
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>Админ тест</title></head>
<body>
    <h2>Вход администратора</h2>
    <?php if ($error): ?><p style="color:red"><?= htmlspecialchars($error) ?></p><?php endif; ?>
    <form method="POST">
        <input type="text" name="login" placeholder="Admin26" required><br><br>
        <input type="password" name="pass" placeholder="Demo20" required><br><br>
        <button type="submit">Войти</button>
    </form>
</body>
</html>