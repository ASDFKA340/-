<?php
// Перенаправляем на страницу входа (главная точка входа)
header('Location: login.php');
exit;
?>