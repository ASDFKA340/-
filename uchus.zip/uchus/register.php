<?php
session_start();
require_once 'config.php';
$error = $success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login']);
    $password = trim($_POST['password']);
    $fullname = trim($_POST['fullname']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    if (!preg_match('/^[A-Za-z0-9]{6,}$/', $login)) $error = 'Логин должен содержать латинские буквы и цифры, минимум 6 символов.';
    elseif (strlen($password) < 8) $error = 'Пароль должен быть не менее 8 символов.';
    elseif (empty($fullname)) $error = 'Введите ФИО.';
    else {
        $check = mysqli_query($conn, "SELECT id FROM users WHERE login = '$login'");
        if (mysqli_num_rows($check) > 0) $error = 'Логин уже занят.';
        else {
            $query = "INSERT INTO users (login, password, fullname, phone, email) VALUES ('$login', '$password', '$fullname', '$phone', '$email')";
            if (mysqli_query($conn, $query)) $success = 'Регистрация успешна! <a href="login.php">Войти</a>';
            else $error = 'Ошибка БД: ' . mysqli_error($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация - Учусь.РФ</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="form-card">
    <h2><i class="fas fa-user-plus"></i> Регистрация</h2>
    <?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="success"><?= $success ?></div><?php endif; ?>
    <form method="POST">
        <div class="form-group"><label>Логин (латиница+цифры, мин6)</label><input type="text" name="login" required></div>
        <div class="form-group"><label>Пароль (мин8)</label><input type="password" name="password" required></div>
        <div class="form-group"><label>ФИО</label><input type="text" name="fullname" required></div>
        <div class="form-group"><label>Телефон</label><input type="text" name="phone"></div>
        <div class="form-group"><label>E-mail</label><input type="email" name="email"></div>
        <button type="submit">Зарегистрироваться</button>
        <div class="links"><a href="login.php">Уже есть аккаунт? Войти</a></div>
    </form>
</div>
</body>
</html>