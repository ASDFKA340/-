CREATE DATABASE IF NOT EXISTS uchus_db;
USE uchus_db;

-- Таблица пользователей
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,   -- храним пароль в открытом виде (упрощенно, но можно и хэш)
    fullname VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(100)
);

-- Таблица заявок
CREATE TABLE applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    course_name VARCHAR(100) NOT NULL,
    start_date VARCHAR(10) NOT NULL,  -- ДД.ММ.ГГГГ
    payment_method VARCHAR(50),
    status ENUM('Новая', 'Идет обучение', 'Обучение завершено') DEFAULT 'Новая',
    review TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Вставка тестового администратора (не в таблицу users, а просто для проверки)
-- Для админа используется отдельная проверка логина/пароля Admin26/Demo20
-- Также добавим тестового пользователя
INSERT INTO users (login, password, fullname, phone, email) VALUES
('student1', 'pass12345', 'Анна Смирнова', '+79123456789', 'anna@example.com');
INSERT INTO applications (user_id, course_name, start_date, payment_method, status) VALUES
(1, 'Курс повышения квалификации', '15.05.2026', 'Банковская карта', 'Новая');